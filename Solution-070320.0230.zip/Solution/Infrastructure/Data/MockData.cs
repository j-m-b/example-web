﻿using System;
using System.Collections.Generic;
using System.Linq;
using Domain.Entities;

namespace Infrastructure.Data {

  public static class MockData {

    public static List<Employee> GetEmployees() {
      List<Employee> list = new List<Employee> {
        // Add Employees (cover test cases)
        new NonManager("Jamie", "Binkley", "Store"),
        new NonManager("Xavier", "Roberts", "Other"),
        // Add Managers (cover test cases)
        new Manager("John", "Doe", "Store", "Sales Manager"),
        new Manager("Jane", "Doe", "Store", "Other"),
        new Manager("Missy", "Elliot", "Other", "Other")
      };
      return list;
    }
    public static Employee GetRandomEmployee() {
      List<Employee> list = GetEmployees();
      return list.ElementAt(new Random(DateTime.Now.Millisecond).Next(list.Count()));
    }
  }
}
