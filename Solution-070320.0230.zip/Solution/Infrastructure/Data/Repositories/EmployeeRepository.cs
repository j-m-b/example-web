﻿using Domain.Interfaces;
using Domain.Entities;
using Infrastructure.Data.Context;
using System.Collections.Generic;

namespace Infrastructure.Data.Repositories {
  public class EmployeeRepository : IEmployeeRepository {
    public EmployeeDbContext _context;
    public EmployeeRepository(EmployeeDbContext context) { 
      _context = context;
    }
    public IEnumerable<Employee> GetEmployees() {
      return _context.Employees;
    }
  }
}
// repository pattern futher reading:
//  https://codewithshadman.com/repository-pattern-csharp/