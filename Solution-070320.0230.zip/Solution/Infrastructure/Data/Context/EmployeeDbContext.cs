﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
// ToDo: never implemented using Context ... There is only an in-memory example atm and prioritizing front-end on the second day

namespace Infrastructure.Data.Context {
  public class EmployeeDbContext : DbContext {
    //public EmployeeDbContext() : base() { }
    public EmployeeDbContext(DbContextOptions<EmployeeDbContext> options) : base(options)  { }
    public DbSet<Employee> Employees { get; set; }
    // bandaid for Keyless dilemma
    // see: https://github.com/dotnet/EntityFramework.Docs/blob/master/samples/core/KeylessEntityTypes/Program.cs
    protected override void OnModelCreating(ModelBuilder modelBuilder) {
      modelBuilder.Entity<EmployeeDbContext>(eb => { eb.HasNoKey(); });
    }
  }
}
