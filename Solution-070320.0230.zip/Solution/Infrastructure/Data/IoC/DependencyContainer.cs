﻿using Application.Interfaces;
using Application.Services;
using Domain.Interfaces;
using Infrastructure.Data.Repositories;
using Microsoft.Extensions.DependencyInjection;

/// <summary>
/// Single point of reference connecting the interfaces and thier implementations
/// </summary>
namespace Infrastructure.Data.IoC {
  public class DependencyContainer {
    public static void RegisterServices(IServiceCollection services) {
      services.AddScoped<IEmployeeService, EmployeeService>();
      // Domain.Interfaces | Infrastructure.Data.Repositories
      services.AddScoped<IEmployeeRepository, EmployeeRepository>();
      // AddScoped<>(): https://docs.microsoft.com/en-us/dotnet/api/microsoft.extensions.dependencyinjection.servicecollectionserviceextensions.addscoped
    }
  }
}
