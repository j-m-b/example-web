﻿using Application.Interfaces;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication.Models;

namespace WebApplication.Controllers {
  public class HomeController : Controller {
     
    //private IEmployeeService _service; // ToDo: Implement service to return data using context

    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger/*, IEmployeeService service*/) {
      _logger = logger;
      //_service = service;
    }

    //[ResponseCache(NoStore = true, Duration = 0)]
    public IActionResult Index() {
      // ToDo: this should really come from service; however, that's still not up to par
      //return View(Infrastructure.Data.MockData.GetEmployees()); 
      return View();
    }

    public IActionResult GetRandomEmployeeJson() {
      return Json(Infrastructure.Data.MockData.GetRandomEmployee());
    }

    public IActionResult GetEmployeesJson() {
      // ToDo: this should really come from service; however, that's still not up to par
      return Json(Infrastructure.Data.MockData.GetEmployees());
    }

    public IActionResult Privacy() {
      return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}
