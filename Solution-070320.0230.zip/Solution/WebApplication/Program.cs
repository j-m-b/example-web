using Infrastructure.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace WebApplication {
  public class Program {
    public static void Main(string[] args) {
      CreateHostBuilder(args).Build().Run();
      /* Can't work out the DbContext ... bailing on this to prioritize Front End
      // 1. Who's hosting?
      IHost host = CreateHostBuilder(args).Build();
      // 2. Where's services?
      using (IServiceScope scope = host.Services.CreateScope()) {
        // 3. Get the instance of EmployeeDbContext in our services layer
        IServiceProvider services = scope.ServiceProvider;
        EmployeeDbContext context = services.GetRequiredService<EmployeeDbContext>();
        // 4. Ring DataGenerator for mock data
        Models.DataGenerator.Initialize(services);
      }
      // Run
      host.Run();
      */
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureWebHostDefaults(webBuilder => {
              webBuilder.UseStartup<Startup>();
            });
  }
}
