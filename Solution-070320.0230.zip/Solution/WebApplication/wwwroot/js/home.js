﻿function format(d) { // for hide/show rows
  // `d` is the original data object for the row
  return '<table cellpadding="5" cellspacing="0" border="1" width="100%" style="padding-left:50px;">' +
    '<tr>' +
    '<td width="35%">Responsibilities:</td>' +
    '<td>' + d.responsibilities.toString().replace(/,/g, ", ") + '</td>' + // space after comma
    '</tr>' +
    '</table>';
}

$(document).ready(function () {

  //$('#employees').DataTable(); // datatables.net zero config
  var table = $('#employees').DataTable({ // https://datatables.net/examples/api/row_details.html
    "ajax": { // https://datatables.net/examples/ajax/custom_data_flat.html (because there isn't 'data' in the json response)
      "url": "/Home/GetEmployeesJson",
      "dataSrc": ""
    },
    "columns": [
      {
        "className": 'details-control',
        "orderable": false,
        "data": null,
        "defaultContent": ''
      },
      { data : "displayName" }
    ],
    "order": [[1, 'asc']]
  });

  // Add event listener for opening and closing details in datatable
  $('#employees tbody').on('click', 'td.details-control', function () {
    var tr = $(this).closest('tr');
    var row = table.row(tr);
    if (row.child.isShown()) {
      // This row is already open - close it
      row.child.hide();
      tr.removeClass('shown');
    }
    else {
      // Open this row
      row.child(format(row.data())).show(); // Responsibilities
      tr.addClass('shown');
    }
  });

  // modal popup
  $("#ShowModal").click(function () {
    $("#Modal").modal('show');
  });
  $("#HideModal").click(function () {
    $("#Modal").modal('hide');
  });

});