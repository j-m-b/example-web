﻿using Domain.Entities;
using Infrastructure.Data.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
// ToDo: this is not working out, come back when time permits
namespace WebApplication.Models {
  public class DataGenerator {
    public static void Initialize(IServiceProvider provider) {
      using EmployeeDbContext context = new EmployeeDbContext(
        provider.GetRequiredService<DbContextOptions<EmployeeDbContext>>());
      // check if database was seeded, bail if so
      if (context.Employees.Any()) { return; }
      // otherwise, let's add data here
      context.Employees.AddRange(
        new NonManager("Jamie", "Binkley", "Store"),
        new NonManager("Xavier", "Roberts", "Other"),
        // Add Managers (cover test cases)
        new Manager("John", "Doe", "Store", "Sales Manager"),
        new Manager("Jane", "Doe", "Store", "Other"),
        new Manager("Missy", "Elliot", "Other", "Other")
      ); // provider
      context.SaveChanges();
    }
  }
}
