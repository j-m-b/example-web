﻿namespace Domain.Entities {
  /// <summary>Immutable Manager Child Class with a "is-a" relationship to Employee Parent Class</summary>
  public class Manager : Employee {
    public string Title { get; }
    /// <summary>Ctor for Manager employee</summary>
    /// <param name="firstname"></param>
    /// <param name="lastname"></param>
    /// <param name="location"></param>
    /// <param name="title"></param>
    public Manager(string firstname, string lastname, string location, string title) : base(firstname, lastname, location) {
      Title = title;
      DisplayName += " (" + title + ")";
      // Decided to leave this here ... 
      if (Location == "Store" && Title == "Sales Manager") {
        Responsibilities.Add("Oversee Floor");
        Responsibilities.Add("Customer Service");
      } else {
        Responsibilities.Add("Oversee Warehouse");
      }
    }
  }
}