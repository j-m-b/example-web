﻿namespace Domain.Entities {
  /// <summary>Immutable Non Manager Child Class with a "is-a" relationship to Employee Parent Class</summary>
  public class NonManager : Employee {
    /// <summary>Ctor for a Non Manager Employee</summary>
    /// <param name="firstname"></param>
    /// <param name="lastname"></param>
    /// <param name="location"></param>
    public NonManager(string firstname, string lastname, string location) : base(firstname, lastname, location) {
      // Leaving this here just like in Manager Ctor ... 
      if (Location == "Store") {
        Responsibilities.Add("Stock Shelves");
        Responsibilities.Add("Customer Service");
      } else {
        Responsibilities.Add("Load Warehouse Trucks");
      }
    }
  }
}