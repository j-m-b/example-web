﻿using System.Collections.Generic;
// using System.ComponentModel.DataAnnotations;
// Notes: There may need to be a parameterless ctor for EF as well as property adjustments.
//        Pretty much using an immutable object is not a goot idea (serialization, context, etc issues)
//        p.s. Responsibilities property being a list doesn't help the cause either
/// <summary>Core Layer</summary>
namespace Domain.Entities {
  /// <summary>Base Class for all Employees</summary>
  public abstract class Employee : Interfaces.IEmployee {
    public string FirstName { get; }
    public string LastName { get; }
    public string Location { get; }
    public string DisplayName { get; protected set; }
    public IList<string> Responsibilities { get; }
    /// <summary>Ctor for any Employee</summary>
    /// <param name="firstname"></param>
    /// <param name="lastname"></param>
    /// <param name="location"></param>
    public Employee(string firstname, string lastname, string location) {
      FirstName = firstname;
      LastName = lastname;
      Location = location;
      DisplayName = firstname + " " + lastname;
      Responsibilities = new List<string>();
    }
  }
}