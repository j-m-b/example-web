﻿using System.Collections.Generic;

namespace Domain.Interfaces {
  /// <summary>Contract for all Employees</summary>
  public interface IEmployee {
    string FirstName { get; }
    string LastName { get; }
    string Location { get; }
    string DisplayName { get; }
    IList<string> Responsibilities { get; }
  }
}