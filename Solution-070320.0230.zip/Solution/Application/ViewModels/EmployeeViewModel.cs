﻿using Domain.Entities;
using System.Collections.Generic;

namespace Application.ViewModels {
  public class EmployeeViewModel {
    public IEnumerable<Employee> Employees { get; set; }
  }
}
