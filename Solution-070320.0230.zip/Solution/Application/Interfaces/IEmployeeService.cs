﻿using Application.ViewModels;

namespace Application.Interfaces {
  public interface IEmployeeService {
    EmployeeViewModel GetEmployees();
  }
}
