﻿using Application.Interfaces;
using Application.ViewModels;
using Domain.Interfaces;
using System.Text.Json;

namespace Application.Services {
  public class EmployeeService : IEmployeeService {
    public IEmployeeRepository _repository;
    public EmployeeService(IEmployeeRepository repository) {
      _repository = repository;
    }
    public EmployeeViewModel GetEmployees() {
      return new EmployeeViewModel() {
        Employees = _repository.GetEmployees()
      };
    }
  }
}
